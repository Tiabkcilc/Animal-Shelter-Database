from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user="aacuser", password="StrongPassword123", host="localhost", port=27017, db="aac", col="animals"):
        """
        Initialize the MongoClient. Defaults connect to the aac database,
        animals collection, with the aacuser account.
        """
        # Connection variables
        USER = user
        PASS = password
        HOST = host
        PORT = port
        DB = db
        COL = col

        # Build MongoDB connection string
        mongo_uri = f"mongodb://{USER}:{PASS}@{HOST}:{PORT}"

        # Initialize Connection
        self.client = MongoClient(mongo_uri)
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # -----------------------------
    # CREATE: Insert a document
    # -----------------------------
    def create(self, data):
        """
        Insert a document into the collection.
        :param data: dictionary containing key/value pairs
        :return: True if insert was successful, else False
        """
        if data is None or not isinstance(data, dict):
            raise Exception("Invalid data: must provide a non-empty dictionary.")

        try:
            result = self.collection.insert_one(data)  # insert document
            return True if result.inserted_id else False
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False

    # -----------------------------
    # READ: Query documents
    # -----------------------------
    def read(self, query):
        """
        Query documents from the collection.
        :param query: dictionary with key/value pair for lookup
        :return: list of matching documents, empty list if none found
        """
        if query is None or not isinstance(query, dict):
            raise Exception("Invalid query: must provide a dictionary.")

        try:
            cursor = self.collection.find(query)  # find returns a cursor
            results = list(cursor)  # convert cursor to list
            return results
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []

    # -----------------------------
    # UPDATE: Update documents
    # -----------------------------
    def update(self, query, new_values):
        """
        Update documents in the collection.
        :param query: dictionary filter for documents to update
        :param new_values: dictionary of fields to update
        :return: number of documents modified
        """
        if query is None or not isinstance(query, dict):
            raise Exception("Invalid query: must provide a dictionary.")

        try:
            result = self.collection.update_many(query, new_values)
            return result.modified_count
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0

    # -----------------------------
    # DELETE: Delete documents
    # -----------------------------
    def delete(self, query):
        """
        Delete documents from the collection.
        :param query: dictionary filter for documents to delete
        :return: number of documents deleted
        """
        if query is None or not isinstance(query, dict):
            raise Exception("Invalid query: must provide a dictionary.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return 0
